<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Laboratorio 2.9</title>
    </head>
    <body>
        <?php
                for($i=0;$i<10;$i++){
                    echo "el valor de i es ", $i, "<br>";
                }
        ?>
    </body>