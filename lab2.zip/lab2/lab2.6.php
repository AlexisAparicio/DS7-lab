<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Laboratorio 2.6</title>
    </head>
    <body>
        <?php
        $a =5;
        $b="5";
       echo($a==5)?"Verdadero":"falso","<br>";
       echo($a===5)?"Verdadero":"falso","<br>";
       echo($b==5)?"Verdadero":"falso","<br>";
       echo($b===5)?"Verdadero":"falso","<br>";
        ?>
    </body>
</html>