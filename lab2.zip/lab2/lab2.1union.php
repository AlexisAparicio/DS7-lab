<?php include("lab2.1header.php");  ?>
<p>Hola , este es el contenido</p>
<?php include("lab2.1footer.php"); ?>
