<?php 
include ("noexiste.php");
echo("Hola el script continuo");
?>