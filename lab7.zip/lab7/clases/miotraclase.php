<?php
class miotraclase{
    public function __construct(){

        echo "MMi Segunda clase a sido agregada!!!<br>";
    }
}
?>