<html>
    <head>
        <title> Laboratorio 1.2</title>

    </head>
    <body>
        <?php
        $n1=1;
        $n2=1;
        $Suma=$n1+$n2;
        echo "suma = ".$Suma. "<br>";
        echo $n1+$n2;
        ?>
    </body>
</html>